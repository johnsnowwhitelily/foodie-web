package me.itslucas.hw8;

import java.util.ArrayList;

public class Friends {
    public ArrayList<Friend> data;

    public ArrayList<Friend> getData() {
        return data;
    }

    public void setData(ArrayList<Friend> data) {
        this.data = data;
    }
}
