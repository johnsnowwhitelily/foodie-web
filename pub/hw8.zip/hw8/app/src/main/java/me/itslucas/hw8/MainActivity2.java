package me.itslucas.hw8;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class MainActivity2 extends AppCompatActivity {
    private Button button;
    private TextView textView;
    Friends friends;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        button = findViewById(R.id.button);
        textView = findViewById(R.id.textView);
        Gson gson = new Gson();
        button.setOnClickListener(view -> {
                new Thread(() -> {
                    String httpUrl = "http://teapot.itslucas.me/getfriend.php";
                    String resultData = "";
                    URL url = null;
                    try {
                        url = new URL(httpUrl);
                    } catch (MalformedURLException e) {
                        System.out.println(e.getMessage());
                    }
                    HttpURLConnection urlConn = null;
                    try {
                        urlConn = (HttpURLConnection) url.openConnection();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    InputStreamReader in = null;
                    try {
                        in = new InputStreamReader(urlConn.getInputStream());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    BufferedReader buffer = new BufferedReader(in);
                    String inputLine = null;
                    while (true) {
                        try {
                            if (!((inputLine = buffer.readLine()) != null)) break;
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        resultData += inputLine + "\n";
                    }
                    try {
                        in.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    urlConn.disconnect();
                    friends = new Gson().fromJson(resultData, Friends.class);
                }).start();
                textView.setText("");
                while(friends == null) {
                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                for (Friend f : friends.getData()) {
                    textView.append("Name: " + f.getName() + " Phone: " + f.getPhone());
                    textView.append("\n");
                }
        });
    }
}